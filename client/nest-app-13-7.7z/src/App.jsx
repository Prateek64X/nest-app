import React from 'react';
import Home from './pages/Home';

const App = () => {
  return (
    <div className='container mx-auto px-4 py-6'>
      <Home />
    </div>
  );
}

export default App;